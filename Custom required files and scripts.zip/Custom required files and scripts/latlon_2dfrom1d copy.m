function [lat2d,lon2d] = latlon_2dfrom1d(lat1d,lon1d)

%Creates 2D lat/lon arrays from 1D inputs
lat2d=NaN.*ones(length(lon1d),length(lat1d));
lon2d=NaN.*ones(length(lon1d),length(lat1d));
for i=1:length(lon1d)
    for j=1:length(lat1d)
        lat2d(i,j)=lat1d(j);
        lon2d(i,j)=lon1d(i);
    end
end
westernhem=lon2d>180;lon2d(westernhem)=lon2d(westernhem)-360; %so range of lons is -180 to 180


end