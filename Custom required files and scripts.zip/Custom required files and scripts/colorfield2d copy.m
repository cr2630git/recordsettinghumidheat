function output = colorfield2d(topleftcolor,bottomrightcolor,toprightcolor,numcolorsalongeachaxis,incrcontrast,maxpalenessfactor)

%Creates a 2D color field, intended to represent variable 1 in the top left
%and variable 2 in the bottom right, with their combination at the top right
%Distance from the bottom left (which is white) toward each vertex corresponds to relative intensity

%Originally written for Thompson replication project, spring 2024
%Colin Raymond (csraymond@ucla.edu)

colorshading=zeros(numcolorsalongeachaxis,numcolorsalongeachaxis,3);
i_topleft=1;j_topleft=1; %row & col of top left corner
i_topright=1;j_topright=numcolorsalongeachaxis; %row & col of top right corner
i_bottomleft=numcolorsalongeachaxis;j_bottomleft=1; %row & col of bottom left corner
i_bottomright=numcolorsalongeachaxis;j_bottomright=numcolorsalongeachaxis; %row & col of bottom right corner

bottomleftcolor=colors('white');

%The amount of each univariate color in a square is proportional to its
%positioning on a line connecting that color's origin corner to a diagonal line through the center
for i=1:numcolorsalongeachaxis %row
    for j=1:numcolorsalongeachaxis %col
        %Deal with top left
        %First, define the line to use
        slope=(i-i_topleft)/(j-j_topleft);intercept=i_topleft-slope*j_topleft;

        %Now continue along this line, away from the top left, until i+j>numcolorsalongeachaxis 
        % -- that's the farthest extremity of the top-left influence
        myweight=1; %to initialize
        if j==1
            i_edge=numcolorsalongeachaxis;j_edge=1;
        elseif i+j>numcolorsalongeachaxis
            myweight=0;
        else
            continueon=1;j_test=j;
            while continueon==1 %keep inching to the right (and/or down)
                j_test=j_test+0.1;i_test=slope*j_test+intercept;
                if i_test+j_test>numcolorsalongeachaxis;continueon=0;end
            end
            i_edge=round2(i_test,1,'ceil');j_edge=round2(j_test,1,'ceil');
        end
        if i_edge>numcolorsalongeachaxis;i_edge=numcolorsalongeachaxis;end;if i_edge<1;i_edge=1;end
        if j_edge>numcolorsalongeachaxis;j_edge=numcolorsalongeachaxis;end;if j_edge<1;j_edge=1;end
        

        %Now, what fraction down this line is the query point?
        %This gives the weight of the top-left color
        if myweight~=0
            mydist=sqrt((i-i_topleft)^2+(j-j_topleft)^2);
            linelength=sqrt((i_edge-i_topleft)^2+(j_edge-j_topleft)^2);
            weight_topleft(i,j)=1-mydist/linelength;
        else
            weight_topleft(i,j)=0;
        end


        %Deal with bottom right
        %First, define the line to use
        slope=(i-i_bottomright)/(j-j_bottomright);intercept=i_bottomright-slope*j_bottomright;

        %Now continue along this line, away from the bottom right, until i+j<numcolorsalongeachaxis -- 
            %that's the farthest extremity of the bottom-right influence
        myweight=1; %to initialize
        if j==numcolorsalongeachaxis
            i_edge=1;j_edge=numcolorsalongeachaxis;
        elseif i+j<numcolorsalongeachaxis
            myweight=0;
        else
            continueon=1;j_test=j;
            while continueon==1 %keep inching to the left (& up)
                j_test=j_test-0.1;i_test=slope*j_test+intercept;
                if i_test+j_test<numcolorsalongeachaxis;continueon=0;end
            end
            i_edge=round2(i_test,1,'ceil');j_edge=round2(j_test,1,'ceil');
        end
        if i_edge>numcolorsalongeachaxis;i_edge=numcolorsalongeachaxis;end;if i_edge<1;i_edge=1;end
        if j_edge>numcolorsalongeachaxis;j_edge=numcolorsalongeachaxis;end;if j_edge<1;j_edge=1;end

        %Now, what fraction down this line is the query point?
        %This gives the weight of the bottom-right color
        if myweight~=0
            mydist=sqrt((i-i_bottomright)^2+(j-j_bottomright)^2);
            linelength=sqrt((i_edge-i_bottomright)^2+(j_edge-j_bottomright)^2);
            weight_bottomright(i,j)=1-mydist/linelength;
        else
            weight_bottomright(i,j)=0;
        end



        %Deal with top right
        %Weight is more simply just the distance between the query point and the top right
        mydist=sqrt((i-i_topright)^2+(j-j_topright)^2);
        truemaxdist=sqrt((numcolorsalongeachaxis-1)^2+(numcolorsalongeachaxis-1)^2);
        weight_topright(i,j)=1-mydist/truemaxdist;

        %Deal with bottom left
        slope=abs((i-i_bottomleft)/(j-j_bottomleft));intercept=i_bottomleft-slope*j_bottomleft;
        if slope>1 %line will intersect top edge (i=1) -- but where?
            i_edge=1;j_edge=j_bottomleft-(numcolorsalongeachaxis-1)/slope; %numcolorsalongeachaxis-1 is box height
        else %line will intersect right edge (j=numcolorsalongeachaxis)
            j_edge=numcolorsalongeachaxis;i_edge=i_bottomleft-(numcolorsalongeachaxis-1)*slope; %numcolorsalongeachaxis-1 is box width
        end
        mydist=sqrt((i-i_bottomleft)^2+(j-j_bottomleft)^2);
        linelength=sqrt((i_edge-i_bottomleft)^2+(j_edge-j_bottomleft)^2);
        weight_bottomleft(i,j)=1-mydist/linelength;


        colorshading(i,j,:)=weight_topleft(i,j).*topleftcolor+weight_topright(i,j).*toprightcolor+weight_bottomleft(i,j).*bottomleftcolor+...
            weight_bottomright(i,j)*bottomrightcolor;

        %Make white corner paler as well
        if incrcontrast==1
            curcolor=colorshading(i,j,:);
            difffrommax=max(max(curcolor))-curcolor;
            newcolor=curcolor+maxpalenessfactor*weight_bottomleft(i,j)*difffrommax;
            colorshading(i,j,:)=newcolor;
        end
    end
end
colorshading(numcolorsalongeachaxis,1,:)=[1 1 1];

%Ensure no values > 1
curmax=max(max(max(colorshading)));
if curmax<1.5 %just divide
    colorshading=colorshading./curmax;
else
    disp('Need help in colorfield2d!');return;
end

output=colorshading;

end