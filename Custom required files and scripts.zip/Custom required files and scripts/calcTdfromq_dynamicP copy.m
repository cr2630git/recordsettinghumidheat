function tdarray = calcTdfromq_dynamicP(qarray,sfcP)

%Calculates Td (C) from q (g/kg) and sfc pressure (hPa), using the formula of Bolton 1980
    %(listed at https://www.eol.ucar.edu/projects/ceop/dm/documents/refdata_report/eqns.html)

%Table for validation: http://www.michell.com/us/calculator/


%First, compute vapor pressure (Pa)
vp=(sfcP.*(qarray./1000))./(0.622+0.378.*(qarray./1000));

%vp=vp./100; %convert vp to hPa

%Then, compute Td (C)
tdarray=log(vp./6.112).*243.5./(17.67-log(vp./6.112));

end