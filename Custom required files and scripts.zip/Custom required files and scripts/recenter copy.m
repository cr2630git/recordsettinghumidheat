function newarr = recenter(arr)
%Recenter lat/lon array from 180 to 0 (Prime Meridian)
%Assumes array is already oriented with lat as rows and lon as cols
%Also need to have an even number of cols (this condition is almost always already satisfied)

nlon=size(arr,2);
changepos180toneg180=arr==180;arr(changepos180toneg180)=-180;
newarr=[arr(:,nlon/2+1:nlon) arr(:,1:nlon/2)];
end